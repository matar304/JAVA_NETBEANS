/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controleur;

import Dao.Connecte;
import Model.TraitementEtatFinancier;
import Model.TraitementEtudiant;
import Model.TraitementPaiement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import javax.swing.JTable;

/**
 *
 * @author ideal
 */
public class controlEtatFinancier {
  
    public void EtatFinancier_Updat(TraitementEtatFinancier pt){
       //connexion
        Connecte cb=new Connecte();
        cb.connect();
        
        //requete
        String rep="update etatfinancier set totalPaiement=(SELECT SUM(montantdepaiement)FROM paiement WHERE idEtat = '" + pt.getIdEtat() + "') where idEtat='"+pt.getIdEtat()+"'";
        
        try {
            //execution
            cb.st.executeUpdate(rep);
            JOptionPane.showMessageDialog(null, "L'etudiant a été modifié avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(controlEtudiant.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erreur lors de la mise à jour de l'étudiant");
        }
    }  

   //methode EtatFinancier_Del
    public void EtatFinancier_Del(int idEtat) {
    Connecte cb = new Connecte();
    cb.connect();
    //requete sql
    String rep="Delete from etatfinancier where idEtat='"+idEtat+"'";
        try {
            cb.st.executeUpdate(rep);
            JOptionPane.showMessageDialog(null, "L'etat de paiement a été supprimé avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(controlEtatFinancier.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    //methode Paiement_Find
    public TraitementEtatFinancier EtatFinancier_Find  (int idEtat){
    TraitementEtatFinancier p=null;
    p=new TraitementEtatFinancier();
    ResultSet rs=null;
    Connecte cb=new Connecte();
    cb.connect();
    String req="select*from etatfinancier where idEtat='"+idEtat+"'";
        try {
          rs= cb.st.executeQuery(req);
          if(rs.next()){
              p.setIdEtat(rs.getInt("idEtat"));
              p.setTotalPaiement(rs.getDouble("totalPaiement"));
              p.setId(rs.getInt("id"));
          }
          else{
            JOptionPane.showMessageDialog(null, "aucun etat de paiement trouvé");
        }
        } catch (SQLException ex) {
            Logger.getLogger(controlEtatFinancier.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }
    

    //methode EtatFinancier_Liste
    public ResultSet EtatFinancier_Liste(){
        ResultSet rs=null;
        TraitementPaiement p=new TraitementPaiement();
        Connecte cb=new Connecte();
        cb.connect();
        
        String rep="Select * from etatfinancier";

        try {
            rs=cb.st.executeQuery(rep);
        } catch (SQLException ex) {
            Logger.getLogger(controlEtatFinancier.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
        
    }
 
    
   public static void main (String []args){
       
       int totalPaiement = 0;
       TraitementEtudiant p = new TraitementEtudiant();
       TraitementPaiement pe = new TraitementPaiement();
       TraitementEtatFinancier pt = new TraitementEtatFinancier();
       controlEtatFinancier co=new controlEtatFinancier();
       //co.EtatFinancier_Add();
        
       // Saisir l'ID de l'etudiant
       Scanner scanner = new Scanner(System.in);
        System.out.println("Veuillez saisir l'ID de l'etudiant" );
        int id=scanner.nextInt();
       // Afficher les informations de l'étudiant
        System.out.println("Prenom: " + p.getPrenom());
        System.out.println("Nom: " + p.getNom());

        // Afficher les paiements de l'étudiant
            System.out.println("Paiement de: " + pe.getDesignation() + ", Montant: " + pe.getMontantdepaiement());
        

        // Calculer la somme totale des paiements
        totalPaiement += pe.getMontantdepaiement();
        System.out.println("La somme totale des paiements est : " + totalPaiement);
    }
    
     public static void imprimer(JTable jt, String titre){
        MessageFormat entete= new MessageFormat(titre);
        MessageFormat pied= new MessageFormat("Page(0,number,integer)");
    
    try{
        jt.print(JTable.PrintMode.FIT_WIDTH,entete, pied);
        }catch (Exception e){
        JOptionPane.showMessageDialog(null, "Erreur :\n"+e,"Impression",JOptionPane.ERROR_MESSAGE);
    }
    }
    } 
   
   
   
   
   


