/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controleur;

/**
 *
 * @author Matar Ndoye KEITA
 */
import Dao.Connecte;
import Model.TraitementEtudiant;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.*;

public class controlEtudiant {

    //methode d'ajout de etudiant
    public void Etudiant_Add(TraitementEtudiant e){
        //connexion à la base
        Connecte cb=new Connecte();
        cb.connect();
        //requete sql
        String rep="insert into etudiant (prenom, nom, adresse, tel, mail, lieudenaissance, datedenaissance, domaine, niveau, genre, anneeacademique, filiere)values('"+e.getPrenom()+"','"+e.getNom()+"','"+e.getAdresse()+"','"+e.getTel()+"','"+e.getMail()+"','"+e.getLieudenaissance()+"','"+e.getDatedenaissance()+"','"+e.getDomaine()+"','"+e.getNiveau()+"','"+e.getGenre()+"','"+e.getAnneeacademique()+"','"+e.getFiliere()+"')";
    
        try {
            //execution
            cb.st.executeUpdate(rep);
            JOptionPane.showMessageDialog(null, "L'etudiant a été ajouté avec succès");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
            Logger.getLogger(controlEtudiant.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //methode Etudiant_Update
    public void Etudiant_Update(TraitementEtudiant e){
       //connexion
        Connecte cb=new Connecte();
        cb.connect();
        
        //requete
        String rep="update etudiant set prenom='"+e.getPrenom()+"',nom='"+e.getNom()+"',adresse='"+e.getAdresse()+"',tel='"+e.getTel()+"',mail='"+e.getMail()+"',lieudenaissance='"+e.getLieudenaissance()+"',datedenaissance='"+e.getDatedenaissance()+"',domaine='"+e.getDomaine()+"',niveau='"+e.getNiveau()+"',genre='"+e.getGenre()+"',anneeacademique='"+e.getAnneeacademique()+"',filiere='"+e.getFiliere()+"' where id='"+e.getId()+"'";
      
        
        try {
            //execution
            cb.st.executeUpdate(rep);
            JOptionPane.showMessageDialog(null, "L'etudiant a été modifié avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(controlEtudiant.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erreur lors de la mise à jour de l'étudiant");
        }
    }
    
    //methode Etudiant_Del
    public void Etudiant_Del(int id){
        Connecte cb=new Connecte();
        cb.connect();
        
        String rep="Delete from etudiant where id='"+id+"'";
        try {
            cb.st.executeUpdate(rep);
            JOptionPane.showMessageDialog(null, "L'etudiant a été supprimé avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(controlEtudiant.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    //methode Etudiant_Find
    public TraitementEtudiant Etudiant_Find  (int id){
    TraitementEtudiant e=null;
    e=new TraitementEtudiant();
    ResultSet rs=null;
    Connecte cb=new Connecte();
    cb.connect();
    String req="select*from etudiant where id='"+id+"'";
        try {
          rs= cb.st.executeQuery(req);
          if(rs.next()){
              e.setId(rs.getInt("id"));
              e.setPrenom(rs.getString("prenom"));
              e.setNom(rs.getString("nom"));
              e.setAdresse(rs.getString("adresse"));
              e.setTel(rs.getString("tel"));
              e.setMail(rs.getString("mail"));
              e.setLieudenaissance(rs.getString("lieudenaissance"));
              e.setDatedenaissance(rs.getString("datedenaissance"));
              e.setDomaine(rs.getString("domaine"));
              e.setNiveau(rs.getString("niveau"));
              e.setGenre(rs.getString("genre"));
              e.setAnneeacademique(rs.getString("anneeacademique"));
              e.setFiliere(rs.getString("filiere"));
              
          }
          else{
            JOptionPane.showMessageDialog(null, "aucun etudiant trouvé");
        }
        } catch (SQLException ex) {
            Logger.getLogger(controlEtudiant.class.getName()).log(Level.SEVERE, null, ex);
        }
        return e;
        
}
    
    //methode Etudiant_Liste
    public ResultSet Etudiant_Liste(){
        ResultSet rs=null;
        TraitementEtudiant e=new TraitementEtudiant();
        Connecte cb=new Connecte();
        cb.connect();
        
        String rep="Select * from etudiant ";

        try {
            rs=cb.st.executeQuery(rep);
        } catch (SQLException ex) {
            Logger.getLogger(controlEtudiant.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
        
    }   
    
    public static void imprimer(JTable jt, String titre){
        MessageFormat entete= new MessageFormat(titre);
        MessageFormat pied= new MessageFormat("Page(0,number,integer)");
    
    try{
        jt.print(JTable.PrintMode.FIT_WIDTH,entete, pied);
        }catch (Exception e){
        JOptionPane.showMessageDialog(null, "Erreur :\n"+e,"Impression",JOptionPane.ERROR_MESSAGE);
    }
    }
}

