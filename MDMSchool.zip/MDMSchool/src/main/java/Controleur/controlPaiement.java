/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controleur;

import Dao.Connecte;
import Model.TraitementPaiement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;

/**
 *
 * @author ideal
 */
public class controlPaiement {
    //methode d'ajout de paiement
    public void Paiement_Add(TraitementPaiement p){
        //connexion à la base
        Connecte cb=new Connecte();
        cb.connect();
        //requete sql
        String rep="insert into paiement (designation, montantdepaiement, datedepaiement, id)values('"+p.getDesignation()+"','"+p.getMontantdepaiement()+"','"+p.getDatedepaiement()+"','"+p.getId()+"')";
    
        try {
            //execution
            cb.st.executeUpdate(rep);
            JOptionPane.showMessageDialog(null, "Le paeiment est ajouté avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(controlPaiement.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   
    //methode Paiement_Update
    public void Paiement_Update(TraitementPaiement p){
       //connexion
        Connecte cb=new Connecte();
        cb.connect();
        
        //requete
        String rep="update paiement set designation='"+p.getDesignation()+"',montantdepaiement='"+p.getMontantdepaiement()+"',datedepaiement='"+p.getDatedepaiement()+"',id='"+p.getId()+"' where idPaiement='"+p.getIdPaiement()+"'";
        
        try {
            //execution
            cb.st.executeUpdate(rep);
            JOptionPane.showMessageDialog(null, "Paiement a été modifié avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(controlPaiement.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //methode Paiement_Del
    public void Paiement_Del(int idPaiement){
        Connecte cb=new Connecte();
        cb.connect();
        
        String rep="Delete from paiement where idPaiement='"+idPaiement+"'";
        try {
            cb.st.executeUpdate(rep);
            JOptionPane.showMessageDialog(null, "Paiement a été supprimé avec succès");
        } catch (SQLException ex) {
            Logger.getLogger(controlPaiement.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    //methode Paiement_Find
    public TraitementPaiement Paiement_Find  (int idPaiement){
    TraitementPaiement p=null;
    p=new TraitementPaiement();
    ResultSet rs=null;
    Connecte cb=new Connecte();
    cb.connect();
    String req="select*from paiement where idPaiement='"+idPaiement+"'";
        try {
          rs= cb.st.executeQuery(req);
          if(rs.next()){
              p.setIdPaiement(rs.getInt("idPaiement"));
              p.setDesignation(rs.getString("designation"));
              p.setMontantdepaiement(rs.getInt("montantdepaiement"));
              p.setDatedepaiement(rs.getString("datedepaiement"));
              p.setId(rs.getInt("id"));
              
          }
          else{
            JOptionPane.showMessageDialog(null, "aucun paiement trouvé");
        }
        } catch (SQLException ex) {
            Logger.getLogger(controlPaiement.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
        
}
    
//methode Paiement_Liste
    public ResultSet Paiement_Liste(){
        ResultSet rs=null;
        TraitementPaiement p=new TraitementPaiement();
        Connecte cb=new Connecte();
        cb.connect();
        
        String rep="Select * from paiement ";

        try {
            rs=cb.st.executeQuery(rep);
        } catch (SQLException ex) {
            Logger.getLogger(controlPaiement.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
        
    }    
    public static void imprimer(JTable jt, String titre){
        MessageFormat entete= new MessageFormat(titre);
        MessageFormat pied= new MessageFormat("Page(0,number,integer)");
    
    try{
        jt.print(JTable.PrintMode.FIT_WIDTH,entete, pied);
        }catch (Exception e){
        JOptionPane.showMessageDialog(null, "Erreur :\n"+e,"Impression",JOptionPane.ERROR_MESSAGE);
    }
    }
}
