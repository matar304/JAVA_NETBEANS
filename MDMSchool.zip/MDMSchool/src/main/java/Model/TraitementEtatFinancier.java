/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author ideal
 */
public class TraitementEtatFinancier {
    private int idEtat;
    private double totalPaiement;
     private int id;
    
    
//constructeur sans arguments
    public TraitementEtatFinancier() {
    }
    
//constructeur avec arguments

    public TraitementEtatFinancier(int idEtat, double totalPaiement,int id) {
        this.idEtat = idEtat;
        this.totalPaiement = totalPaiement;
        this.id=id;
    }
    
//constructeur avec arguments sans idEtat

    public TraitementEtatFinancier(double totalPaiement,int id) {
        this.totalPaiement = totalPaiement;
        this.id=id;
    }
    
//getters

    public int getIdEtat() {
        return idEtat;
    }

    public double getTotalPaiement() {
        return totalPaiement;
    }

    public int getId() {
        return id;
    }
    
    
//setters

    public void setIdEtat(int idEtat) {
        this.idEtat = idEtat;
    }

    public void setTotalPaiement(double totalPaiement) {
        this.totalPaiement = totalPaiement;
    }

    public void setId(int id) {
        this.id = id;
    }

}



