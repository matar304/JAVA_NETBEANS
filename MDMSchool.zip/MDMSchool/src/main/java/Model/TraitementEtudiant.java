/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Matar Ndoye KEITA
 */
public class TraitementEtudiant {
    private int id;
    private String prenom;
    private String nom;
    private String adresse;
    private String tel;
    private String mail;
    private String lieudenaissance;
    private String datedenaissance;
    private String domaine;
    private String niveau;
    private String genre;
    private String anneeacademique;
    private String filiere;

    
    //constructeur sans arguments
    public TraitementEtudiant() {
    }
    
    // Constructeur avec arguments sans id
    public TraitementEtudiant(String prenom, String nom, String adresse, String tel, String mail, String lieudenaissance, String datedenaissance, String domaine, String niveau, String genre, String anneeacademique, String filiere) {
        this.prenom = prenom;
        this.nom = nom;
        this.adresse = adresse;
        this.tel = tel;
        this.mail = mail;
        this.lieudenaissance = lieudenaissance;
        this.datedenaissance = datedenaissance;
        this.domaine = domaine;
        this.niveau = niveau;
        this.genre = genre;
        this.anneeacademique = anneeacademique;
        this.filiere = filiere;
    }
    
    //constructeur avec arguments

    public TraitementEtudiant(int id, String prenom, String nom, String adresse, String tel,String mail, String lieudenaissance, String datedenaissance, String domaine, String niveau, String genre, String anneeacademique, String filiere) {
        this.id = id;
        this.prenom = prenom;
        this.nom = nom;
        this.adresse = adresse;
        this.tel = tel;
        this.mail = mail;
        this.lieudenaissance = lieudenaissance;
        this.datedenaissance = datedenaissance;
        this.domaine = domaine;
        this.niveau = niveau;
        this.genre = genre;
        this.anneeacademique = anneeacademique;
        this.filiere = filiere;
    }

    //getter
    public int getId() {
        return id;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getNom() {
        return nom;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getTel() {
        return tel;
    }

    public String getMail() {
        return mail;
    }

    public String getLieudenaissance() {
        return lieudenaissance;
    }

    public String getDatedenaissance() {
        return datedenaissance;
    }

    public String getDomaine() {
        return domaine;
    }

    public String getNiveau() {
        return niveau;
    }

    public String getGenre() {
        return genre;
    }

    public String getAnneeacademique() {
        return anneeacademique;
    }

    public String getFiliere() {
        return filiere;
    }
    
//setters
    
    public void setId(int id) {
        this.id = id;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public void setLieudenaissance(String lieudenaissance) {
        this.lieudenaissance = lieudenaissance;
    }

    public void setDatedenaissance(String datedenaissance) {
        this.datedenaissance = datedenaissance;
    }

    public void setDomaine(String domaine) {
        this.domaine = domaine;
    }

    public void setNiveau(String niveau) {
        this.niveau = niveau;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setAnneeacademique(String anneeacademique) {
        this.anneeacademique = anneeacademique;
    }

    public void setFiliere(String filiere) {
        this.filiere = filiere;
    }
 }
    


    
    