/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Matar Ndoye KEITA
 */
public class TraitementPaiement {
    private int idPaiement;
    private String designation;
    private int montantdepaiement;
    private String datedepaiement;
    private int id;
    
    
    //constructeur sans arguments
    public TraitementPaiement() {
    }
    
    //constructeur avec arguments sans id

    public TraitementPaiement(String designation, int montantdepaiement, String datedepaiement, int id) {
        this.designation = designation;
        this.montantdepaiement = montantdepaiement;
        this.datedepaiement = datedepaiement;
        this.id = id;
    }
    
    //constructeur avec arguments 

    public TraitementPaiement(int idPaiement, String designation, int montantdepaiement, String datedepaiement, int id) {
        this.idPaiement = idPaiement;
        this.designation = designation;
        this.montantdepaiement = montantdepaiement;
        this.datedepaiement = datedepaiement;
        this.id = id;
    }
    
    
    //getters
    public int getIdPaiement() {
        return idPaiement;
    }
    public String getDesignation() {
        return designation;
    }
    public int getMontantdepaiement() {
        return montantdepaiement;
    }
    public String getDatedepaiement() {
        return datedepaiement;
    }
    public int getId() {
        return id;
    }
    
    //setters
    public void setIdPaiement(int idPaiement) {
        this.idPaiement = idPaiement;
    }
    public void setDesignation(String designation) {
        this.designation = designation;
    }
    public void setMontantdepaiement(int montantdepaiement) {
        this.montantdepaiement = montantdepaiement;
    }
    public void setDatedepaiement(String datedepaiement) {
        this.datedepaiement = datedepaiement;
    }
    public void setId(int id) {
        this.id = id;
    }
    
}
